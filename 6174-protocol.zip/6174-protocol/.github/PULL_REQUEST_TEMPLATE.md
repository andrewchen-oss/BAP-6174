<!--
Thank you for contributing to BAP-6174.
Please fill in the relevant sections and delete the rest.
-->

## Summary

<!-- One paragraph: what does this PR change and why? -->

## Classification

- [ ] Spec clarification (wording, typo, formatting)
- [ ] Spec change (adds / removes / modifies a MUST / SHOULD / MAY clause)
- [ ] Interface change (modifies `IBAP6174.sol` or `IBAP6174Verifier.sol`)
- [ ] New NFA specification (NFA-007+)
- [ ] Invariant change (adds / removes / modifies INV-*)
- [ ] Documentation-only (README, glossary, guides)
- [ ] Tooling (CI, package.json, hardhat config)

## Breaking change?

- [ ] Yes — this PR changes a normative MUST or invariant
- [ ] No — additive / clarifying only

## Checklist

- [ ] Whitepaper (`whitepaper/BAP-6174-v0.1.html`) updated, **or** PR is code/tooling-only
- [ ] Matching `docs/specs/NFA-00X-*.md` updated
- [ ] `docs/invariants.md` updated if INV-* is touched
- [ ] `CHANGELOG.md` entry added under `## Unreleased`
- [ ] `pnpm compile` passes locally
- [ ] NatSpec on modified interface functions reflects new behaviour
- [ ] For interface changes: Clawdyland reference implementation has been notified

## Related issues

<!-- Closes #... / Relates to #... -->
